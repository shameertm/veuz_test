



window.addEventListener("scroll", function(){
    var header = this.document.querySelector("nav");
    header.classList.toggle("header-scrolled", window.scrollY > 50)
})





let navbar = document.querySelector('.header .navbar')

document.querySelector('#menu-btn').onclick = () => {
    navbar.classList.add('active')
}

document.querySelector('#close-navbar').onclick = () => {
    navbar.classList.remove('active')
}



